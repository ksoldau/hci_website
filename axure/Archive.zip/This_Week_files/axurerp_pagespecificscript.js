﻿for(var i = 0; i < 126; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u80'] = 'top';gv_vAlignTable['u83'] = 'center';
u84.style.cursor = 'pointer';
$axure.eventManager.click('u84', function(e) {

if ((GetCheckState('u84')) == (false)) {

	SetPanelState('u81', 'pd0u81','none','',500,'none','',500);

SetCheckState('u84', true);

}
});
gv_vAlignTable['u85'] = 'top';gv_vAlignTable['u87'] = 'center';
u88.style.cursor = 'pointer';
$axure.eventManager.click('u88', function(e) {

if ((GetCheckState('u88')) == (true)) {

	SetPanelState('u81', 'pd1u81','none','',500,'none','',500);

SetCheckState('u88', false);

}
});
gv_vAlignTable['u89'] = 'top';gv_vAlignTable['u92'] = 'center';
u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

	SetPanelVisibility('u4','hidden','none',500);

}
});

u12.style.cursor = 'pointer';
$axure.eventManager.click('u12', function(e) {

if (true) {

	SetPanelVisibility('u4','hidden','none',500);

}
});
gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u110'] = 'center';
u111.style.cursor = 'pointer';
$axure.eventManager.click('u111', function(e) {

if ((GetCheckState('u111')) == (false)) {

	SetPanelState('u108', 'pd0u108','none','',500,'none','',500);

SetCheckState('u111', true);

}
});
gv_vAlignTable['u112'] = 'top';gv_vAlignTable['u114'] = 'center';
u115.style.cursor = 'pointer';
$axure.eventManager.click('u115', function(e) {

if ((GetCheckState('u115')) == (true)) {

	SetPanelState('u108', 'pd1u108','none','',500,'none','',500);

SetCheckState('u115', false);

}
});
gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u25'] = 'top';document.getElementById('u26_img').tabIndex = 0;

u26.style.cursor = 'pointer';
$axure.eventManager.click('u26', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Index.html');

}
});
gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u101'] = 'center';
u102.style.cursor = 'pointer';
$axure.eventManager.click('u102', function(e) {

if ((GetCheckState('u102')) == (false)) {

	SetPanelState('u99', 'pd0u99','none','',500,'none','',500);

SetCheckState('u102', true);

}
});
gv_vAlignTable['u103'] = 'top';gv_vAlignTable['u105'] = 'center';
u106.style.cursor = 'pointer';
$axure.eventManager.click('u106', function(e) {

if ((GetCheckState('u106')) == (true)) {

	SetPanelState('u99', 'pd1u99','none','',500,'none','',500);

SetCheckState('u106', false);

}
});
gv_vAlignTable['u107'] = 'top';gv_vAlignTable['u31'] = 'center';
u33.style.cursor = 'pointer';
$axure.eventManager.click('u33', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Today.html');

}
});

u35.style.cursor = 'pointer';
$axure.eventManager.click('u35', function(e) {

if (true) {

	self.location.href='#';

	self.location.href=$axure.globalVariableProvider.getLinkUrl('This_Month.html');

}
});

u36.style.cursor = 'pointer';
$axure.eventManager.click('u36', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Next_12_months.html');

}
});

u37.style.cursor = 'pointer';
$axure.eventManager.click('u37', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('List.html');

}
});
gv_vAlignTable['u39'] = 'center';
u93.style.cursor = 'pointer';
$axure.eventManager.click('u93', function(e) {

if ((GetCheckState('u93')) == (false)) {

	SetPanelState('u90', 'pd0u90','none','',500,'none','',500);

SetCheckState('u93', true);

}
});
gv_vAlignTable['u94'] = 'top';gv_vAlignTable['u96'] = 'center';
u97.style.cursor = 'pointer';
$axure.eventManager.click('u97', function(e) {

if ((GetCheckState('u97')) == (true)) {

	SetPanelState('u90', 'pd1u90','none','',500,'none','',500);

SetCheckState('u97', false);

}
});
gv_vAlignTable['u98'] = 'top';gv_vAlignTable['u116'] = 'top';gv_vAlignTable['u119'] = 'center';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u43'] = 'center';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u49'] = 'center';
u120.style.cursor = 'pointer';
$axure.eventManager.click('u120', function(e) {

if ((GetCheckState('u120')) == (false)) {

	SetPanelState('u117', 'pd0u117','none','',500,'none','',500);

SetCheckState('u120', true);

}
});
gv_vAlignTable['u121'] = 'top';gv_vAlignTable['u123'] = 'center';
u124.style.cursor = 'pointer';
$axure.eventManager.click('u124', function(e) {

if ((GetCheckState('u124')) == (true)) {

	SetPanelState('u117', 'pd1u117','none','',500,'none','',500);

SetCheckState('u124', false);

}
});
gv_vAlignTable['u125'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u2'] = 'top';
u3.style.cursor = 'pointer';
$axure.eventManager.click('u3', function(e) {

if (true) {

	SetPanelVisibility('u4','','none',500);

}
});
gv_vAlignTable['u6'] = 'center';
$axure.eventManager.keyup('u7', function(e) {

if (true) {

	var obj1 = document.getElementById("u12");
    obj1.disabled = false;

}
});
gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u57'] = 'top';gv_vAlignTable['u58'] = 'top';gv_vAlignTable['u59'] = 'top';gv_vAlignTable['u65'] = 'center';
u66.style.cursor = 'pointer';
$axure.eventManager.click('u66', function(e) {

if ((GetCheckState('u66')) == (false)) {

	SetPanelState('u63', 'pd0u63','none','',500,'none','',500);

SetCheckState('u66', true);

}
});
gv_vAlignTable['u67'] = 'top';gv_vAlignTable['u69'] = 'center';
u70.style.cursor = 'pointer';
$axure.eventManager.click('u70', function(e) {

if ((GetCheckState('u70')) == (true)) {

	SetPanelState('u63', 'pd1u63','none','',500,'none','',500);

SetCheckState('u70', false);

}
});
gv_vAlignTable['u71'] = 'top';gv_vAlignTable['u74'] = 'center';
u75.style.cursor = 'pointer';
$axure.eventManager.click('u75', function(e) {

if ((GetCheckState('u75')) == (false)) {

	SetPanelState('u72', 'pd0u72','none','',500,'none','',500);

SetCheckState('u75', true);

}
});
gv_vAlignTable['u76'] = 'top';gv_vAlignTable['u78'] = 'center';
u79.style.cursor = 'pointer';
$axure.eventManager.click('u79', function(e) {

if ((GetCheckState('u79')) == (true)) {

	SetPanelState('u72', 'pd1u72','none','',500,'none','',500);

SetCheckState('u79', false);

}
});
