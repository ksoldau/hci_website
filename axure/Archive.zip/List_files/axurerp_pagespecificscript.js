﻿for(var i = 0; i < 124; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u80'] = 'top';
u81.style.cursor = 'pointer';
$axure.eventManager.click('u81', function(e) {

if (true) {

	SetPanelVisibility('u82','','none',500);

}
});
gv_vAlignTable['u84'] = 'center';
$axure.eventManager.keyup('u85', function(e) {

if (true) {

	var obj1 = document.getElementById("u90");
    obj1.disabled = false;

}
});
gv_vAlignTable['u86'] = 'top';gv_vAlignTable['u87'] = 'top';
u89.style.cursor = 'pointer';
$axure.eventManager.click('u89', function(e) {

if (true) {

	SetPanelVisibility('u82','hidden','none',500);

}
});

u90.style.cursor = 'pointer';
$axure.eventManager.click('u90', function(e) {

if (true) {

	SetPanelVisibility('u82','hidden','none',500);

}
});
gv_vAlignTable['u91'] = 'top';
u92.style.cursor = 'pointer';
$axure.eventManager.click('u92', function(e) {

if (true) {

	SetPanelVisibility('u100','','none',500);

}
});

u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Week.html');

}
});

u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Month.html');

}
});

u12.style.cursor = 'pointer';
$axure.eventManager.click('u12', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Year.html');

}
});

u14.style.cursor = 'pointer';
$axure.eventManager.click('u14', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Today.html');

}
});
gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u17'] = 'top';
u110.style.cursor = 'pointer';
$axure.eventManager.click('u110', function(e) {

if (true) {

	SetPanelVisibility('u111','','none',500);

}
});
gv_vAlignTable['u113'] = 'center';gv_vAlignTable['u114'] = 'top';gv_vAlignTable['u20'] = 'center';
u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if ((GetCheckState('u21')) == (false)) {

	SetPanelState('u18', 'pd0u18','none','',500,'none','',500);

SetCheckState('u21', true);

}
});
gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u24'] = 'center';
u25.style.cursor = 'pointer';
$axure.eventManager.click('u25', function(e) {

if ((GetCheckState('u25')) == (true)) {

	SetPanelState('u18', 'pd1u18','none','',500,'none','',500);

SetCheckState('u25', false);

}
});
gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u102'] = 'center';gv_vAlignTable['u104'] = 'center';u106.tabIndex = 0;

u106.style.cursor = 'pointer';
$axure.eventManager.click('u106', function(e) {

if (true) {

	SetPanelVisibility('u100','hidden','none',500);

}
});
gv_vAlignTable['u106'] = 'top';
u107.style.cursor = 'pointer';
$axure.eventManager.click('u107', function(e) {

if (true) {

	SetPanelVisibility('u100','hidden','none',500);

}
});

u108.style.cursor = 'pointer';
$axure.eventManager.click('u108', function(e) {

if (true) {

	SetPanelVisibility('u100','hidden','none',500);

}
});

u30.style.cursor = 'pointer';
$axure.eventManager.click('u30', function(e) {

if ((GetCheckState('u30')) == (false)) {

	SetPanelState('u27', 'pd0u27','none','',500,'none','',500);

SetCheckState('u30', true);

}
});
gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u33'] = 'center';
u34.style.cursor = 'pointer';
$axure.eventManager.click('u34', function(e) {

if ((GetCheckState('u34')) == (true)) {

	SetPanelState('u27', 'pd1u27','none','',500,'none','',500);

SetCheckState('u34', false);

}
});
gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u38'] = 'center';
u39.style.cursor = 'pointer';
$axure.eventManager.click('u39', function(e) {

if ((GetCheckState('u39')) == (false)) {

	SetPanelState('u36', 'pd0u36','none','',500,'none','',500);

SetCheckState('u39', true);

}
});
gv_vAlignTable['u93'] = 'top';gv_vAlignTable['u95'] = 'top';gv_vAlignTable['u97'] = 'top';gv_vAlignTable['u99'] = 'top';gv_vAlignTable['u116'] = 'top';gv_vAlignTable['u118'] = 'top';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u42'] = 'center';
u43.style.cursor = 'pointer';
$axure.eventManager.click('u43', function(e) {

if ((GetCheckState('u43')) == (true)) {

	SetPanelState('u36', 'pd1u36','none','',500,'none','',500);

SetCheckState('u43', false);

}
});
gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u48'] = 'center';
u49.style.cursor = 'pointer';
$axure.eventManager.click('u49', function(e) {

if ((GetCheckState('u49')) == (false)) {

	SetPanelState('u46', 'pd0u46','none','',500,'none','',500);

SetCheckState('u49', true);

}
});

u120.style.cursor = 'pointer';
$axure.eventManager.click('u120', function(e) {

if (true) {

	SetPanelVisibility('u111','hidden','none',500);

}
});

u121.style.cursor = 'pointer';
$axure.eventManager.click('u121', function(e) {

if (true) {

	SetPanelVisibility('u111','hidden','none',500);

}
});
gv_vAlignTable['u123'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u2'] = 'top';document.getElementById('u3_img').tabIndex = 0;

u3.style.cursor = 'pointer';
$axure.eventManager.click('u3', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Index.html');

}
});
gv_vAlignTable['u4'] = 'center';gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u52'] = 'center';
u53.style.cursor = 'pointer';
$axure.eventManager.click('u53', function(e) {

if ((GetCheckState('u53')) == (true)) {

	SetPanelState('u46', 'pd1u46','none','',500,'none','',500);

SetCheckState('u53', false);

}
});
gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u57'] = 'center';
u58.style.cursor = 'pointer';
$axure.eventManager.click('u58', function(e) {

if ((GetCheckState('u58')) == (false)) {

	SetPanelState('u55', 'pd0u55','none','',500,'none','',500);

SetCheckState('u58', true);

}
});
gv_vAlignTable['u59'] = 'top';gv_vAlignTable['u61'] = 'center';
u62.style.cursor = 'pointer';
$axure.eventManager.click('u62', function(e) {

if ((GetCheckState('u62')) == (true)) {

	SetPanelState('u55', 'pd1u55','none','',500,'none','',500);

SetCheckState('u62', false);

}
});
gv_vAlignTable['u63'] = 'top';gv_vAlignTable['u64'] = 'top';gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u68'] = 'center';
u69.style.cursor = 'pointer';
$axure.eventManager.click('u69', function(e) {

if ((GetCheckState('u69')) == (false)) {

	SetPanelState('u66', 'pd0u66','none','',500,'none','',500);

SetCheckState('u69', true);

}
});
gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u72'] = 'center';
u73.style.cursor = 'pointer';
$axure.eventManager.click('u73', function(e) {

if ((GetCheckState('u73')) == (true)) {

	SetPanelState('u66', 'pd1u66','none','',500,'none','',500);

SetCheckState('u73', false);

}
});
gv_vAlignTable['u74'] = 'top';gv_vAlignTable['u79'] = 'center';