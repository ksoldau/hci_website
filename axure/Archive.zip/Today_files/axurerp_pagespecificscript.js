﻿for(var i = 0; i < 102; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u81'] = 'center';gv_vAlignTable['u83'] = 'center';u85.tabIndex = 0;

u85.style.cursor = 'pointer';
$axure.eventManager.click('u85', function(e) {

if (true) {

	SetPanelVisibility('u79','hidden','none',500);

}
});
gv_vAlignTable['u85'] = 'top';
u86.style.cursor = 'pointer';
$axure.eventManager.click('u86', function(e) {

if (true) {

	SetPanelVisibility('u79','hidden','none',500);

}
});

u87.style.cursor = 'pointer';
$axure.eventManager.click('u87', function(e) {

if (true) {

	SetPanelVisibility('u79','hidden','none',500);

}
});
gv_vAlignTable['u91'] = 'center';gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u10'] = 'center';
u12.style.cursor = 'pointer';
$axure.eventManager.click('u12', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Week.html');

}
});

u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Month.html');

}
});

u14.style.cursor = 'pointer';
$axure.eventManager.click('u14', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Year.html');

}
});

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	self.location.href='#';

	self.location.href=$axure.globalVariableProvider.getLinkUrl('List.html');

}
});

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	SetPanelVisibility('u89','','none',500);

}
});
gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u18'] = 'top';
u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	SetPanelVisibility('u89','','none',500);

}
});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u25'] = 'center';
u26.style.cursor = 'pointer';
$axure.eventManager.click('u26', function(e) {

if ((GetCheckState('u26')) == (false)) {

	SetPanelState('u23', 'pd0u23','none','',500,'none','',500);

SetCheckState('u26', true);

	MoveWidgetTo('u23', GetNum('200'), GetNum('220'),'none',500);

}
});
gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u101'] = 'center';
u30.style.cursor = 'pointer';
$axure.eventManager.click('u30', function(e) {

if ((GetCheckState('u30')) == (true)) {

	SetPanelState('u23', 'pd1u23','none','',500,'none','',500);

SetCheckState('u30', false);

	MoveWidgetTo('u23', GetNum('600'), GetNum('220'),'none',500);

}
});
gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u36'] = 'center';
u37.style.cursor = 'pointer';
$axure.eventManager.click('u37', function(e) {

if ((GetCheckState('u37')) == (false)) {

	SetPanelState('u34', 'pd0u34','none','',500,'none','',500);

SetCheckState('u37', true);

	MoveWidgetTo('u34', GetNum('200'), GetNum('340'),'none',500);

}
});
gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u94'] = 'top';gv_vAlignTable['u96'] = 'top';
u98.style.cursor = 'pointer';
$axure.eventManager.click('u98', function(e) {

if (true) {

	SetPanelVisibility('u89','hidden','none',500);

}
});

u99.style.cursor = 'pointer';
$axure.eventManager.click('u99', function(e) {

if (true) {

	SetPanelVisibility('u89','hidden','none',500);

}
});
gv_vAlignTable['u40'] = 'center';
u41.style.cursor = 'pointer';
$axure.eventManager.click('u41', function(e) {

if ((GetCheckState('u41')) == (true)) {

	SetPanelState('u34', 'pd1u34','none','',500,'none','',500);

SetCheckState('u41', false);

	MoveWidgetTo('u34', GetNum('600'), GetNum('340'),'none',500);

}
});
gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u45'] = 'center';
u46.style.cursor = 'pointer';
$axure.eventManager.click('u46', function(e) {

if ((GetCheckState('u46')) == (false)) {

	SetPanelState('u43', 'pd0u43','none','',500,'none','',500);

SetCheckState('u46', true);

	MoveWidgetTo('u43', GetNum('200'), GetNum('380'),'none',500);

}
});
gv_vAlignTable['u47'] = 'top';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u4'] = 'top';document.getElementById('u5_img').tabIndex = 0;

u5.style.cursor = 'pointer';
$axure.eventManager.click('u5', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Index.html');

}
});
gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u8'] = 'top';
u50.style.cursor = 'pointer';
$axure.eventManager.click('u50', function(e) {

if ((GetCheckState('u50')) == (true)) {

	SetPanelState('u43', 'pd1u43','none','',500,'none','',500);

SetCheckState('u50', false);

	MoveWidgetTo('u43', GetNum('600'), GetNum('380'),'none',500);

}
});
gv_vAlignTable['u51'] = 'top';
u52.style.cursor = 'pointer';
$axure.eventManager.click('u52', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u58'] = 'center';gv_vAlignTable['u59'] = 'top';
u60.style.cursor = 'pointer';
$axure.eventManager.click('u60', function(e) {

if (true) {

	SetPanelVisibility('u61','','none',500);

}
});
gv_vAlignTable['u63'] = 'center';
$axure.eventManager.keyup('u64', function(e) {

if (true) {

	var obj1 = document.getElementById("u69");
    obj1.disabled = false;

}
});
gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u66'] = 'top';
u68.style.cursor = 'pointer';
$axure.eventManager.click('u68', function(e) {

if (true) {

	SetPanelVisibility('u61','hidden','none',500);

}
});

u69.style.cursor = 'pointer';
$axure.eventManager.click('u69', function(e) {

if (true) {

	SetPanelVisibility('u61','hidden','none',500);

}
});
gv_vAlignTable['u70'] = 'top';
u71.style.cursor = 'pointer';
$axure.eventManager.click('u71', function(e) {

if (true) {

	SetPanelVisibility('u79','','none',500);

}
});
gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u74'] = 'top';gv_vAlignTable['u76'] = 'top';gv_vAlignTable['u78'] = 'top';