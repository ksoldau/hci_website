﻿for(var i = 0; i < 40; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u23'] = 'top';document.getElementById('u24_img').tabIndex = 0;

u24.style.cursor = 'pointer';
$axure.eventManager.click('u24', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Index.html');

}
});
gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u29'] = 'center';
u31.style.cursor = 'pointer';
$axure.eventManager.click('u31', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('This_Week.html');

}
});

u32.style.cursor = 'pointer';
$axure.eventManager.click('u32', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('This_Month.html');

}
});

u34.style.cursor = 'pointer';
$axure.eventManager.click('u34', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('List.html');

}
});

u35.style.cursor = 'pointer';
$axure.eventManager.click('u35', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Today.html');

}
});
gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u2'] = 'top';
u3.style.cursor = 'pointer';
$axure.eventManager.click('u3', function(e) {

if (true) {

	SetPanelVisibility('u4','','none',500);

}
});
gv_vAlignTable['u6'] = 'center';
$axure.eventManager.keyup('u7', function(e) {

if (true) {

	var obj1 = document.getElementById("u12");
    obj1.disabled = false;

}
});
gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u9'] = 'top';
u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

	SetPanelVisibility('u4','hidden','none',500);

}
});

u12.style.cursor = 'pointer';
$axure.eventManager.click('u12', function(e) {

if (true) {

	SetPanelVisibility('u4','hidden','none',500);

}
});
gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u19'] = 'top';