﻿for(var i = 0; i < 156; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u155'] = 'center';gv_vAlignTable['u81'] = 'center';
u82.style.cursor = 'pointer';
$axure.eventManager.click('u82', function(e) {

if ((GetCheckState('u82')) == (true)) {

	SetPanelState('u75', 'pd1u75','none','',500,'none','',500);

SetCheckState('u82', false);

}
});
gv_vAlignTable['u83'] = 'top';gv_vAlignTable['u86'] = 'center';
u87.style.cursor = 'pointer';
$axure.eventManager.click('u87', function(e) {

if ((GetCheckState('u87')) == (false)) {

	SetPanelState('u84', 'pd0u84','none','',500,'none','',500);

SetCheckState('u87', true);

}
});
gv_vAlignTable['u88'] = 'top';gv_vAlignTable['u90'] = 'center';
u91.style.cursor = 'pointer';
$axure.eventManager.click('u91', function(e) {

if ((GetCheckState('u91')) == (true)) {

	SetPanelState('u84', 'pd1u84','none','',500,'none','',500);

SetCheckState('u91', false);

}
});
gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u10'] = 'center';
u12.style.cursor = 'pointer';
$axure.eventManager.click('u12', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Today.html');

}
});

u14.style.cursor = 'pointer';
$axure.eventManager.click('u14', function(e) {

if (true) {

	self.location.href='#';

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Month.html');

}
});

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Year.html');

}
});

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('List.html');

}
});
gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u111'] = 'center';
$axure.eventManager.keyup('u112', function(e) {

if (true) {

	var obj1 = document.getElementById("u117");
    obj1.disabled = false;

}
});
gv_vAlignTable['u113'] = 'top';gv_vAlignTable['u114'] = 'top';gv_vAlignTable['u20'] = 'center';gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u28'] = 'center';
u100.style.cursor = 'pointer';
$axure.eventManager.click('u100', function(e) {

if ((GetCheckState('u100')) == (true)) {

	SetPanelState('u93', 'pd1u93','none','',500,'none','',500);

SetCheckState('u100', false);

}
});
gv_vAlignTable['u101'] = 'top';gv_vAlignTable['u106'] = 'center';gv_vAlignTable['u107'] = 'top';
u108.style.cursor = 'pointer';
$axure.eventManager.click('u108', function(e) {

if (true) {

	SetPanelVisibility('u109','','none',500);

}
});
gv_vAlignTable['u129'] = 'center';gv_vAlignTable['u30'] = 'center';gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u95'] = 'center';
u96.style.cursor = 'pointer';
$axure.eventManager.click('u96', function(e) {

if ((GetCheckState('u96')) == (false)) {

	SetPanelState('u93', 'pd0u93','none','',500,'none','',500);

SetCheckState('u96', true);

}
});
gv_vAlignTable['u97'] = 'top';gv_vAlignTable['u99'] = 'center';
u116.style.cursor = 'pointer';
$axure.eventManager.click('u116', function(e) {

if (true) {

	SetPanelVisibility('u109','hidden','none',500);

}
});

u117.style.cursor = 'pointer';
$axure.eventManager.click('u117', function(e) {

if (true) {

	SetPanelVisibility('u109','hidden','none',500);

}
});
gv_vAlignTable['u118'] = 'top';
u119.style.cursor = 'pointer';
$axure.eventManager.click('u119', function(e) {

if (true) {

	SetPanelVisibility('u127','','none',500);

}
});
gv_vAlignTable['u41'] = 'center';
u42.style.cursor = 'pointer';
$axure.eventManager.click('u42', function(e) {

if ((GetCheckState('u42')) == (false)) {

	SetPanelState('u39', 'pd0u39','none','',500,'none','',500);

SetCheckState('u42', true);

}
});
gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u45'] = 'center';
u46.style.cursor = 'pointer';
$axure.eventManager.click('u46', function(e) {

if ((GetCheckState('u46')) == (true)) {

	SetPanelState('u39', 'pd1u39','none','',500,'none','',500);

SetCheckState('u46', false);

}
});
gv_vAlignTable['u47'] = 'top';gv_vAlignTable['u120'] = 'top';gv_vAlignTable['u122'] = 'top';gv_vAlignTable['u124'] = 'top';gv_vAlignTable['u126'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u4'] = 'top';document.getElementById('u5_img').tabIndex = 0;

u5.style.cursor = 'pointer';
$axure.eventManager.click('u5', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Index.html');

}
});
gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u50'] = 'center';
u51.style.cursor = 'pointer';
$axure.eventManager.click('u51', function(e) {

if ((GetCheckState('u51')) == (false)) {

	SetPanelState('u48', 'pd0u48','none','',500,'none','',500);

SetCheckState('u51', true);

}
});
gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u54'] = 'center';
u55.style.cursor = 'pointer';
$axure.eventManager.click('u55', function(e) {

if ((GetCheckState('u55')) == (true)) {

	SetPanelState('u48', 'pd1u48','none','',500,'none','',500);

SetCheckState('u55', false);

}
});
gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u59'] = 'center';gv_vAlignTable['u131'] = 'center';u133.tabIndex = 0;

u133.style.cursor = 'pointer';
$axure.eventManager.click('u133', function(e) {

if (true) {

	SetPanelVisibility('u127','hidden','none',500);

}
});
gv_vAlignTable['u133'] = 'top';
u134.style.cursor = 'pointer';
$axure.eventManager.click('u134', function(e) {

if (true) {

	SetPanelVisibility('u127','hidden','none',500);

}
});

u135.style.cursor = 'pointer';
$axure.eventManager.click('u135', function(e) {

if (true) {

	SetPanelVisibility('u127','hidden','none',500);

}
});
document.getElementById('u137_img').tabIndex = 0;

u137.style.cursor = 'pointer';
$axure.eventManager.click('u137', function(e) {

if (true) {

	SetPanelVisibility('u139','','none',500);

}
});
gv_vAlignTable['u138'] = 'center';
u60.style.cursor = 'pointer';
$axure.eventManager.click('u60', function(e) {

if ((GetCheckState('u60')) == (false)) {

	SetPanelState('u57', 'pd0u57','none','',500,'none','',500);

SetCheckState('u60', true);

}
});
gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u63'] = 'center';
u64.style.cursor = 'pointer';
$axure.eventManager.click('u64', function(e) {

if ((GetCheckState('u64')) == (true)) {

	SetPanelState('u57', 'pd1u57','none','',500,'none','',500);

SetCheckState('u64', false);

}
});
gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u68'] = 'center';
u69.style.cursor = 'pointer';
$axure.eventManager.click('u69', function(e) {

if ((GetCheckState('u69')) == (false)) {

	SetPanelState('u66', 'pd0u66','none','',500,'none','',500);

SetCheckState('u69', true);

}
});
gv_vAlignTable['u141'] = 'center';gv_vAlignTable['u142'] = 'top';gv_vAlignTable['u144'] = 'top';gv_vAlignTable['u146'] = 'top';
u148.style.cursor = 'pointer';
$axure.eventManager.click('u148', function(e) {

if (true) {

	SetPanelVisibility('u139','hidden','none',500);

}
});

u149.style.cursor = 'pointer';
$axure.eventManager.click('u149', function(e) {

if (true) {

	SetPanelVisibility('u139','hidden','none',500);

}
});
gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u72'] = 'center';
u73.style.cursor = 'pointer';
$axure.eventManager.click('u73', function(e) {

if ((GetCheckState('u73')) == (true)) {

	SetPanelState('u66', 'pd1u66','none','',500,'none','',500);

SetCheckState('u73', false);

}
});
gv_vAlignTable['u74'] = 'top';gv_vAlignTable['u77'] = 'center';
u78.style.cursor = 'pointer';
$axure.eventManager.click('u78', function(e) {

if ((GetCheckState('u78')) == (false)) {

	SetPanelState('u75', 'pd0u75','none','',500,'none','',500);

SetCheckState('u78', true);

}
});
gv_vAlignTable['u79'] = 'top';document.getElementById('u150_img').tabIndex = 0;

u150.style.cursor = 'pointer';
$axure.eventManager.click('u150', function(e) {

if (true) {

	SetPanelVisibility('u139','','none',500);

}
});
gv_vAlignTable['u151'] = 'center';gv_vAlignTable['u153'] = 'center';